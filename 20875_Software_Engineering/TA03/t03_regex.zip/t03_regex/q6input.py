ajdsljk func(FistArg(x, y), SecondArg * 5) lkjslkjsa

alskjdlkj

lakjslksajd kj  func(a * 5, b * 5)


