import sys

if len(sys.argv) != 2:
  if some_random_condition:
    bail_out()
  test("  ")

  if other_condition:
    do_something

  sys.exit(0)

